import React from 'react';
import AppMode from '../AppMode.js';

class CreateAccountPage extends React.Component {
    constructor(props) {
        super(props);
    }

}