import React from 'react';

class InfoPage extends React.Component {
    render() {
        return (
            <div className="padded">
                <h3>Under Construction</h3>
            </div>
        );
    }
}

export default InfoPage;